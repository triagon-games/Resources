bl_info = {
    "name": "Generate Plates with Greebles",
    "author": "Mark Kingsnorth",
    "version": (1, 8, 2),
    "blender": (2, 79, 0),
    "description": "Plating and Greebles Generator",
    "warning": "",
    "wiki_url": "",
    "category": "Mesh",
    }
# To support reload properly, try to access a package var,
# if it's there, reload everything
if "bpy" in locals():
    import imp
    imp.reload(plating_functions)
    imp.reload(plating_generator)
    imp.reload(plating_ui)
    imp.reload(standard_greeble_objects)
    imp.reload(greeble_functions)
    imp.reload(greeble_generator)
    imp.reload(greeble_ui)
    imp.reload(plating_greeble_generator)
    print("Reloaded greeble files")
else:
    from .plating_gen import plating_functions
    from .plating_gen import plating_generator
    from .plating_gen import plating_ui
    from .greeble_gen import standard_greeble_objects
    from .greeble_gen import greeble_functions
    from .greeble_gen import greeble_generator
    from .greeble_gen import greeble_ui
    from .plating_greeble_gen import plating_greeble_generator
    print("Imported greeble and plating files")

import bpy

def register():
    """register operator"""
    bpy.utils.register_module(__name__)
    plating_greeble_generator.append_to_menu()

def unregister():
    """unregister operator"""
    bpy.utils.unregister_module(__name__)
    plating_greeble_generator.remove_from_menu()

if __name__ == "__main__":
    register()
