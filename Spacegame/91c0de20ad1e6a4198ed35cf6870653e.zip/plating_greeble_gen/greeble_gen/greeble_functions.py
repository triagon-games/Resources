import bpy
import numpy as np
import mathutils
import bmesh
from mathutils import Vector
from . import standard_greeble_objects

def add_greebles(self, context, bm, faces, no_of_greebles):
    """Add Greebles to faces"""
    if len(faces) > 0:

        #put all the greeble object properties into a list we can reference laterself.
        greeble_object_props = []
        greeble_object_props.clear()
        greeble_object_props.append({"name_prop": "square_1_greeble", "coverage_prop": self.square_1_greeble_coverage, "is_custom": False})
        greeble_object_props.append({"name_prop": "square_2_greeble", "coverage_prop": self.square_2_greeble_coverage, "is_custom": False})
        greeble_object_props.append({"name_prop": "square_3_greeble", "coverage_prop": self.square_3_greeble_coverage, "is_custom": False})
        greeble_object_props.append({"name_prop": "shape_L_greeble", "coverage_prop": self.shape_L_greeble_coverage, "is_custom": False})
        greeble_object_props.append({"name_prop": "shape_T_greeble", "coverage_prop": self.shape_T_greeble_coverage, "is_custom": False})
        greeble_object_props.append({"name_prop": "shape_cylinder_greeble", "coverage_prop": self.shape_cylinder_greeble_coverage, "is_custom": False})

        greeble_object_props.append({"name_prop": self.custom_object_0, "coverage_prop": self.custom_object_coverage_0, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_1, "coverage_prop": self.custom_object_coverage_1, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_2, "coverage_prop": self.custom_object_coverage_2, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_3, "coverage_prop": self.custom_object_coverage_3, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_4, "coverage_prop": self.custom_object_coverage_4, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_5, "coverage_prop": self.custom_object_coverage_5, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_6, "coverage_prop": self.custom_object_coverage_6, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_7, "coverage_prop": self.custom_object_coverage_7, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_8, "coverage_prop": self.custom_object_coverage_8, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_9, "coverage_prop": self.custom_object_coverage_9, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_10, "coverage_prop": self.custom_object_coverage_0, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_11, "coverage_prop": self.custom_object_coverage_1, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_12, "coverage_prop": self.custom_object_coverage_2, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_13, "coverage_prop": self.custom_object_coverage_3, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_14, "coverage_prop": self.custom_object_coverage_4, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_15, "coverage_prop": self.custom_object_coverage_5, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_16, "coverage_prop": self.custom_object_coverage_6, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_17, "coverage_prop": self.custom_object_coverage_7, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_18, "coverage_prop": self.custom_object_coverage_8, "is_custom": True})
        greeble_object_props.append({"name_prop": self.custom_object_19, "coverage_prop": self.custom_object_coverage_9, "is_custom": True})


        # Load the custom greeble objects if any are set
        # custom_object_list = []
        total_coverage = 0

        greeble_objects = {}
        for greeble_object_prop in greeble_object_props:
            object_name = greeble_object_prop['name_prop']
            if object_name != '' and \
                object_name != context.active_object.name:
                coverage = greeble_object_prop['coverage_prop']
                total_coverage+=coverage
                is_custom = greeble_object_prop['is_custom']
                if is_custom:
                    #convert the vertices into world locations to assess orientation later.
                    new_mesh = bpy.data.meshes.new("Greeble")
                    if object_name in context.scene.objects:
                        new_bm = bmesh.new()
                        new_bm.from_mesh(context.scene.objects[object_name].to_mesh(context.scene, apply_modifiers=True, settings='PREVIEW'))
                        for f in new_bm.faces:
                            f.select = False
                        new_bm.transform(context.scene.objects[object_name].matrix_world)
                        new_bm.to_mesh(new_mesh)
                        new_bm.free()
                    greeble_object_prop['object_data'] = new_mesh
                else:
                    if object_name == 'square_1_greeble':
                        greeble_object_prop['object_data'] = standard_greeble_objects.get_square_1_shape_greeble()
                    elif object_name == 'square_2_greeble':
                        greeble_object_prop['object_data'] = standard_greeble_objects.get_square_2_shape_greeble()
                    elif object_name == 'square_3_greeble':
                        greeble_object_prop['object_data'] = standard_greeble_objects.get_square_3_shape_greeble()
                    elif object_name == 'shape_L_greeble':
                        greeble_object_prop['object_data'] = standard_greeble_objects.get_L_shape_greeble()
                    elif object_name == 'shape_T_greeble':
                        greeble_object_prop['object_data'] = standard_greeble_objects.get_T_shape_greeble()
                    elif object_name == 'shape_cylinder_greeble':
                        greeble_object_prop['object_data'] = standard_greeble_objects.get_cylinder_greeble()

        if total_coverage != 0:

            p = []
            greeble_objects = []
            for greeble_object_prop in greeble_object_props:
                object_name = greeble_object_prop['name_prop']
                if object_name != '' and \
                    object_name != context.active_object.name:
                    greeble_objects.append(greeble_object_prop['object_data'])
                    p.append(greeble_object_prop['coverage_prop'] / total_coverage)

            if len(greeble_objects) > 0:
                rng_pattern = np.random.RandomState(self.greeble_random_seed)
                for i in range(0, no_of_greebles):
                    #choose a greeble in a weighted fashion.
                    object_mesh = rng_pattern.choice(greeble_objects, p=p)
                    __add_greebles_to_mesh(self, bm, faces, object_mesh, 1, rng_pattern)

def __add_greebles_to_mesh(self, bm, faces, greeble_obj, no_of_greebles, rng_pattern):
    """Add Greeble object to a mesh"""
    for i in range(0, no_of_greebles):
        f = rng_pattern.choice(faces)


        if f.is_valid and len(f.loops) == 4:

            width = rng_pattern.uniform(self.greeble_min_width, self.greeble_max_width)
            length = rng_pattern.uniform(self.greeble_min_length, self.greeble_max_length)

            slice_1_lerp = rng_pattern.uniform(0, 1 - width)
            slice_2_lerp = slice_1_lerp + width
            slice_3_lerp = rng_pattern.uniform(0, 1 - length)
            slice_4_lerp = slice_3_lerp + length
            #loops
            # v3---a---v0
            # |       |
            # d       b
            # |       |
            # v2---c---v1

            loop_a = f.loops[0]
            loop_b = loop_a.link_loop_next
            loop_c = loop_b.link_loop_next
            loop_d = loop_c.link_loop_next

            v0 = loop_a.vert
            v1 = loop_b.vert
            v2 = loop_c.vert
            v3 = loop_d.vert

            slice1_a = v3.co.lerp(v0.co, slice_1_lerp)
            slice1_b = v2.co.lerp(v1.co, slice_1_lerp)
            slice2_a = v3.co.lerp(v0.co, slice_2_lerp)
            slice2_b = v2.co.lerp(v1.co, slice_2_lerp)

            # the following will make:
            # a-------b
            # |       |
            # |       |
            # |       |
            # d-------c
            point_a = slice1_a.lerp(slice1_b, slice_3_lerp)
            point_b = slice2_a.lerp(slice2_b, slice_3_lerp)
            point_c = slice2_a.lerp(slice2_b, slice_4_lerp)
            point_d = slice1_a.lerp(slice1_b, slice_4_lerp)

            transform_points = [point_a, point_b, point_c, point_d]

            new_height = rng_pattern.uniform(self.greeble_min_height, self.greeble_max_height)

            transform_points = __shift(transform_points, n=rng_pattern.randint(0,len(transform_points)))

            new_mesh = bpy.data.meshes.new("Greeble")
            new_bm = bmesh.new()
            new_bm.from_mesh(greeble_obj)

            __align_object(new_bm, transform_points, f.normal, new_height)

            new_bm.to_mesh(new_mesh)

            new_bm.free()
            bm.from_mesh(new_mesh)

    bm.normal_update()

def __align_object(greeble_bm, transform_points, normal, height):
    """align a given object to a cube shape defined by four transform points defining a square and a height"""
    if len(greeble_bm.verts) > 0:
        greeble_bm.verts.ensure_lookup_table()
        verts = greeble_bm.verts

        #find origin point, which is bottom corner of objectself.
        first_vert_co = verts[0].co
        x_min = first_vert_co[0]
        x_max = first_vert_co[0]
        y_min = first_vert_co[1]
        y_max = first_vert_co[1]
        z_min = first_vert_co[2]
        z_max = first_vert_co[2]
        # for v in verts:
        for i in range(1, len(verts)):
            co = verts[i].co
            if co[0] < x_min:
                x_min = co[0]
            if co[0] > x_max:
                x_max = co[0]
            if co[1] < y_min:
                y_min = co[1]
            if co[1] > y_max:
                y_max = co[1]
            if co[2] < z_min:
                z_min = co[2]
            if co[2] > z_max:
                z_max = co[2]


        point_a = Vector(transform_points[0])
        point_b = Vector(transform_points[1])
        point_c = Vector(transform_points[2])
        point_d = Vector(transform_points[3])

        #go through and for each vert, interpolate its location in the brave new world.
        x_diff = x_max - x_min
        y_diff = y_max - y_min
        z_diff = z_max - z_min
        for v in verts:
            co = v.co

            if x_diff > 0:
                x_lerp = (co.x - x_min) / x_diff
            else:
                x_lerp = 0
            if y_diff > 0:
                y_lerp = (co.y - y_min) / y_diff
            else:
                y_lerp = 0
            if z_diff > 0:
                z_lerp = (co.z - z_min) / z_diff
            else:
                z_lerp = 0

            #now work out where the point will be in the new world.
            line_start = point_a.lerp(point_b, x_lerp)
            line_end = point_d.lerp(point_c, x_lerp)
            base_point = line_start.lerp(line_end, y_lerp)
            new_coord = base_point.lerp(base_point + (normal*height), z_lerp)

            v.co = new_coord

def __shift(seq, n=0):
    """shift a list a given amount"""
    a = n % len(seq)
    return seq[-a:] + seq[:-a]
