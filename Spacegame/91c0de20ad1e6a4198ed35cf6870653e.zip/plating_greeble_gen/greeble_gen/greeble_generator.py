import bpy
import bmesh
from . import greeble_ui
from . import greeble_functions
from bpy.props import (
        IntProperty,
        BoolProperty,
        FloatProperty,
        StringProperty,
        CollectionProperty
        )

class SceneGreebleObject(bpy.types.PropertyGroup):
    """A class representing an object in a scene"""

    name = bpy.props.StringProperty(name="Object Name", default="Unknown")
#
# Class that contains plate creation logic.
#
class GreebleGenerator:
    """Generate Greeble Objects"""

    greeble_amount  = IntProperty(
            name="Greeble Amount",
            description="Amount of Greebles",
            min=0,
            default=25
            )

    greeble_random_seed  = IntProperty(
            name="Greeble Random Seed",
            description="Random Seed Value for creating greebles",
            min=0,
            default=123456
            )

    greeble_min_width  = FloatProperty(
            name="Greeble Min Width",
            description="Minimum Width of a Greeble",
            min=0,
            max=1,
            default=0.2,
            precision=3,
            step=1
            )

    greeble_max_width  = FloatProperty(
            name="Greeble Max Width",
            description="Maximum Width of a Greeble",
            min=0,
            max=1,
            default=0.8,
            precision=3,
            step=1
            )

    greeble_min_length  = FloatProperty(
            name="Greeble Min Length",
            description="Minimum Length of a Greeble",
            min=0,
            max=1,
            default=0.2,
            precision=3,
            step=1
            )

    greeble_max_length  = FloatProperty(
            name="Greeble Max Length",
            description="Maximum Length of a Greeble",
            min=0,
            max=1,
            default=0.8,
            precision=3,
            step=1
            )

    greeble_min_height  = FloatProperty(
            name="Greeble Min Height",
            description="Minimum Height of a Greeble",
            min=0,
            default=0,
            precision=3,
            step=1
            )

    greeble_max_height  = FloatProperty(
            name="Greeble Max Height",
            description="Maximum Height of a Greeble",
            min=0,
            default=0.1,
            precision=3,
            step=1
            )

    #1,2,3 squares and then an L shape and a T shape

    square_1_greeble = BoolProperty(
            name="1 Square Shape",
            default=True,
            description="A Greeble Shape of 1 square",
            )

    square_1_greeble_coverage = FloatProperty(
                    name="Object Coverage",
                    description="Object Coverage",
                    min=0,
                    max=100,
                    default=100,
                    precision=1,
                    step=1,
                    subtype="PERCENTAGE"
                    )

    square_2_greeble = BoolProperty(
            name="2 Square Shape",
            default=True,
            description="A Greeble Shape of 2 squares",
            )

    square_2_greeble_coverage = FloatProperty(
                    name="Object Coverage",
                    description="Object Coverage",
                    min=0,
                    max=100,
                    default=100,
                    precision=1,
                    step=1,
                    subtype="PERCENTAGE"
                    )

    square_3_greeble = BoolProperty(
            name="3 Square Shape",
            default=True,
            description="A Greeble Shape of 3 squares",
            )

    square_3_greeble_coverage = FloatProperty(
                    name="Object Coverage",
                    description="Object Coverage",
                    min=0,
                    max=100,
                    default=100,
                    precision=1,
                    step=1,
                    subtype="PERCENTAGE"
                    )

    shape_L_greeble = BoolProperty(
            name="L Shape",
            default=True,
            description="A Greeble L Shape",
            )

    shape_L_greeble_coverage = FloatProperty(
                    name="Object Coverage",
                    description="Object Coverage",
                    min=0,
                    max=100,
                    default=100,
                    precision=1,
                    step=1,
                    subtype="PERCENTAGE"
                    )

    shape_T_greeble = BoolProperty(
            name="T Shape",
            default=True,
            description="A Greeble T Shape",
            )

    shape_T_greeble_coverage = FloatProperty(
                    name="Object Coverage",
                    description="Object Coverage",
                    min=0,
                    max=100,
                    default=100,
                    precision=1,
                    step=1,
                    subtype="PERCENTAGE"
                    )

    shape_cylinder_greeble = BoolProperty(
            name="Cylinder Shape",
            default=True,
            description="A Greeble Cylinder Shape",
            )

    shape_cylinder_greeble_coverage = FloatProperty(
                    name="Object Coverage",
                    description="Object Coverage",
                    min=0,
                    max=100,
                    default=100,
                    precision=1,
                    step=1,
                    subtype="PERCENTAGE"
                    )

    def get_custom_object_property():
        return StringProperty(name="Custom Object")

    def get_coverage_property():
        return FloatProperty(
                name="Custom Object Coverage",
                description="Custom Object Coverage",
                min=0,
                max=100,
                default=100,
                precision=1,
                step=1,
                subtype="PERCENTAGE"
                )

    custom_objects_count = 20

    custom_object_0 = get_custom_object_property()
    custom_object_coverage_0 = get_coverage_property()
    custom_object_1 = get_custom_object_property()
    custom_object_coverage_1 = get_coverage_property()
    custom_object_2 = get_custom_object_property()
    custom_object_coverage_2 = get_coverage_property()
    custom_object_3 = get_custom_object_property()
    custom_object_coverage_3 = get_coverage_property()
    custom_object_4 = get_custom_object_property()
    custom_object_coverage_4 = get_coverage_property()
    custom_object_5 = get_custom_object_property()
    custom_object_coverage_5 = get_coverage_property()
    custom_object_6 = get_custom_object_property()
    custom_object_coverage_6 = get_coverage_property()
    custom_object_7 = get_custom_object_property()
    custom_object_coverage_7 = get_coverage_property()
    custom_object_8 = get_custom_object_property()
    custom_object_coverage_8 = get_coverage_property()
    custom_object_9 = get_custom_object_property()
    custom_object_coverage_9 = get_coverage_property()

    custom_object_10 = get_custom_object_property()
    custom_object_coverage_10 = get_coverage_property()
    custom_object_11 = get_custom_object_property()
    custom_object_coverage_11 = get_coverage_property()
    custom_object_12 = get_custom_object_property()
    custom_object_coverage_12 = get_coverage_property()
    custom_object_13 = get_custom_object_property()
    custom_object_coverage_13 = get_coverage_property()
    custom_object_14 = get_custom_object_property()
    custom_object_coverage_14 = get_coverage_property()
    custom_object_15 = get_custom_object_property()
    custom_object_coverage_15 = get_coverage_property()
    custom_object_16 = get_custom_object_property()
    custom_object_coverage_16 = get_coverage_property()
    custom_object_17 = get_custom_object_property()
    custom_object_coverage_17 = get_coverage_property()
    custom_object_18 = get_custom_object_property()
    custom_object_coverage_18 = get_coverage_property()
    custom_object_19 = get_custom_object_property()
    custom_object_coverage_19 = get_coverage_property()

    scene_objects = CollectionProperty(type=SceneGreebleObject)

    #cosmetics
    update_draw_only= BoolProperty(default=False, options={'SKIP_SAVE'})
    def update_draw(self, context):
        self.update_draw_only = True

    show_greeble_parameters_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_default_greebles_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_custom_greebles_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})

    def invoke(self, context, event):
        self.scene_objects.clear()
        for object in context.scene.objects:
            if object.name != context.active_object.name and object.type == "MESH":
                item = self.scene_objects.add()
                item.name = object.name
        return self.execute(context)

    # draw out a custom interface as there are a lot of properties.
    def draw(self, context):
        greeble_ui.draw(self, self.layout)

    @classmethod
    def poll(cls, context):
        return context.active_object and \
            ((context.active_object.type == 'MESH' and \
            context.active_object.mode == 'OBJECT') or \
            (context.active_object.type == 'MESH' and \
            context.active_object.mode == 'EDIT' and \
            context.scene.tool_settings.mesh_select_mode[2]) or \
            (context.active_object.type == 'MESH' and \
            context.active_object.mode == 'EDIT' and \
            context.scene.tool_settings.mesh_select_mode[1]))

    def execute(self, context):
        if self.update_draw_only:
            self.update_draw_only = False
            return {'PASS_THROUGH'}
        if bpy.ops.object.mode_set.poll():
            #capture previous edit mode
            previous_mode = bpy.context.active_object.mode
            previous_edit_mode = list(bpy.context.tool_settings.mesh_select_mode)

            # Switching to EDIT edge mode
            bpy.ops.object.mode_set(mode = 'EDIT')

            # read mesh data
            obj = context.edit_object
            me = obj.data
            bm = bmesh.from_edit_mesh(me)

            selected_faces = []
            for f in bm.faces:
                if f.select:
                    selected_faces.append(f)
            if len(selected_faces) == 0:
                selected_faces.extend(bm.faces)

            #call the plate pattern generator.
            greeble_functions.add_greebles(self, context, bm, selected_faces, self.greeble_amount)

            # update the bmmesh
            bmesh.update_edit_mesh(obj.data)
            me.calc_tessface()

            #reset to previous mode
            context.tool_settings.mesh_select_mode = previous_edit_mode

            bpy.ops.object.mode_set(mode = previous_mode)

            return {'FINISHED'}
        return {'CANCELLED'}

    def check(self, context):
        return True
