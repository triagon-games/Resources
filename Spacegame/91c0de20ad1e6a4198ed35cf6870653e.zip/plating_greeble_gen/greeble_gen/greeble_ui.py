# draw out a custom interface as there are a lot of properties.
def draw(self, layout):
    col = layout.column()
    #col.row().separator()

    #Greebles!
    box = col.box()
    row = box.row()
    row.prop(self, "show_greeble_parameters_panel",
        icon="TRIA_DOWN" if self.show_greeble_parameters_panel else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="General Parameters")
    if self.show_greeble_parameters_panel:
        greeble_parameters_panel = box.column()
        greeble_parameters_panel.prop(self, "greeble_amount")
        greeble_parameters_panel.prop(self, "greeble_random_seed", text="Random Seed")
        greeble_parameters_panel.prop(self, "greeble_min_width", text="Min Width")
        greeble_parameters_panel.prop(self, "greeble_max_width", text="Max Width")
        greeble_parameters_panel.prop(self, "greeble_min_length", text="Min Length")
        greeble_parameters_panel.prop(self, "greeble_max_length", text="Max Length")
        greeble_parameters_panel.prop(self, "greeble_min_height", text="Min Height")
        greeble_parameters_panel.prop(self, "greeble_max_height", text="Max Height")

    box = col.box()
    row = box.row()
    row.prop(self, "show_default_greebles_panel",
        icon="TRIA_DOWN" if self.show_default_greebles_panel else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Default Greeble Objects")
    if self.show_default_greebles_panel:
        default_greebles_panel = box.column()
        row = default_greebles_panel.row()
        row.label(text="Squares")
        row.prop(self, "square_1_greeble_coverage", text="Coverage")
        row = default_greebles_panel.row()
        row.label(text="Double Squares")
        row.prop(self, "square_2_greeble_coverage", text="Coverage")
        row = default_greebles_panel.row()
        row.label(text="Triple Squares")
        row.prop(self, "square_3_greeble_coverage", text="Coverage")
        row = default_greebles_panel.row()
        row.label(text="L Shapes")
        row.prop(self, "shape_L_greeble_coverage", text="Coverage")
        row = default_greebles_panel.row()
        row.label(text="T Shapes")
        row.prop(self, "shape_T_greeble_coverage", text="Coverage")
        row = default_greebles_panel.row()
        row.label(text="Cylinders")
        row.prop(self, "shape_cylinder_greeble_coverage", text="Coverage")

    box = col.box()
    row = box.row()
    row.prop(self, "show_custom_greebles_panel",
        icon="TRIA_DOWN" if self.show_custom_greebles_panel else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Custom Greeble Objects")
    if self.show_custom_greebles_panel:
        default_greebles_panel = box.column()
        default_greebles_panel.label(text="Custom Greeble Objects")
        for i in range(0, self.custom_objects_count):
            row = default_greebles_panel.row()
            row.prop_search(data = self,
                            property = "custom_object_" + str(i),
                            search_data = self,
                            search_property = 'scene_objects',
                            text = '')
            row.prop(self, "custom_object_coverage_"+str(i), text="Coverage")
