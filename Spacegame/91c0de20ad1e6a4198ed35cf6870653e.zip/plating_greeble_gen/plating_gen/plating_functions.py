import bpy
import bmesh
import numpy as np
import mathutils
from mathutils import Vector
import functools


def generate_plate_selection_pattern(bm, faces, random_seed, amount, face_selected_prop, groove_edge_marked_prop):
    """Generate a plating pattern over existing edge geometry."""
    #create a list of edges to return
    edges_to_return = []

	#mark the boundary edges as in the grooves.
    for f in faces:
        for e in f.edges:
            for f1 in e.link_faces:
                if not f1[face_selected_prop]:
                    e[groove_edge_marked_prop] = 1
                    edges_to_return.append(e)
                    edges_to_return.append(e.verts[0])
                    edges_to_return.append(e.verts[1])

    #seed this randomly
    rng_pattern = np.random.RandomState(random_seed)

    #iteratively split up the mesh by selecting an edge loop at random,
    #split it, and then randomly selecting another to be split, and so on.
    for x in range(0, amount):
        #select random edge
        bm.edges.ensure_lookup_table()
        current_edge = rng_pattern.choice(rng_pattern.choice(faces).edges)

        edges_to_return.extend(__mark_groove_edges(bm, current_edge, groove_edge_marked_prop))

    return edges_to_return

def create_plates(self, context, bm, greeble_func=None):
    """Create the 3d plates on the mesh topology"""

    #set up custom data layer for tracking the edge groove pattern
    face_selected_prop = bm.faces.layers.int.new('face_selected')
    groove_face_prop = bm.faces.layers.int.new('groove_face')
    groove_inner_face_prop = bm.faces.layers.int.new('groove_inner_face')
    plate_face_prop = bm.faces.layers.int.new('plate_face')
    plate_face_group_prop = bm.faces.layers.int.new('plate_face_group')
    plate_inner_face_prop = bm.faces.layers.int.new('plate_inner_face')
    plate_side_face_prop = bm.faces.layers.int.new('plate_side_face')
    groove_edge_marked_prop = bm.edges.layers.int.new('groove_edge_marked')
    groove_and_side_face_prop = bm.faces.layers.int.new('groove_and_side_face')
    corner_vert_prop = bm.verts.layers.int.new('corner_vert')
    main_corner_vert_prop = bm.verts.layers.int.new('main_corner_vert')

    bm.faces.ensure_lookup_table()

    #capture the selected faces
    selected_faces = []
    is_face_selection_present = False

    edges_pattern = []
    if self.pattern_type == '0':

        #capture any faces already selected
        for f in bm.faces:
            if f.select:
                is_face_selection_present = True
                f[face_selected_prop] = 1
                selected_faces.append(f)
                f.select = False

        if not is_face_selection_present:
            for f in bm.faces:
                f[face_selected_prop] = 1
            selected_faces = bm.faces

        #generate the plate selection pattern.
        edges_pattern = generate_plate_selection_pattern(bm, selected_faces, self.random_seed, self.amount, face_selected_prop, groove_edge_marked_prop)
    elif self.pattern_type == '1':
        for e in bm.edges:
            if e.select:
                e[groove_edge_marked_prop] = 1
                edges_pattern.append(e)
                edges_pattern.append(e.verts[0])
                edges_pattern.append(e.verts[1])
                e.select = False

    #if we are only to output the edge selection, we are finished.
    if self.edge_selection_only:
        for e in edges_pattern:
            if isinstance(e, bmesh.types.BMEdge):
                e.select = True
    else:
        #determine main corners in the selection
        main_corner_vert_id = 0
        for v in edges_pattern:
            if isinstance(v, bmesh.types.BMVert):
                #is this a main corner? ie a vertex with two edges that share a face
                edge_count = 0
                face_indexes = []
                for e in v.link_edges:
                    if e[groove_edge_marked_prop] == 1:
                        edge_count+=1
                        for f in e.link_faces:
                            face_indexes.append(f.index)
                if len(face_indexes) > len(list(set(face_indexes))):
                    #if there are only two edges, mark this as a main corner
                    if edge_count == 2:
                        main_corner_vert_id += 1
                        v[main_corner_vert_prop] = main_corner_vert_id

        #bevel the edges to form the grooves.
        bevelled_edges = bmesh.ops.bevel(bm,
                                        geom=list(set(edges_pattern)),
                                        offset=self.groove_width,
                                        segments=1,
                                        offset_type=0,
                                        vertex_only=False,
                                        clamp_overlap=self.clamp_grooves,
                                        profile=0.5,
                                        loop_slide=True,
                                        material=-1)

        #now the grooves are created, create a list of all the faces to inset for the plates.
        faces_to_inset = []
        for f in bevelled_edges['faces']:
            faces_to_inset.append(f)
            f[groove_face_prop] = 1
            f[groove_inner_face_prop] = 1
            for e in f.edges:
                e[groove_edge_marked_prop] = 0
        groove_verts = []
        #now everything is marked, determine grooves by determining adjacent faces.  More efficient than
        #checking the faces are contained in the whole selection.
        for f in bevelled_edges['faces']:
            for loop in f.loops:
                adjacent_f = loop.link_loop_radial_next.face
                if not adjacent_f[groove_face_prop]:
                    loop.edge[groove_edge_marked_prop] = 1
                    groove_verts.append(loop.edge.verts[0])
                    groove_verts.append(loop.edge.verts[1])

        bm.verts.ensure_lookup_table()
        corner_vert_id = main_corner_vert_id + 1
        #mark minor corners
        for v in groove_verts:
            #is this a corner? ie a vertex with two edges that share a face
            edge_count = 0
            face_indexes = []
            for e in v.link_edges:
                if e[groove_edge_marked_prop] == 1:
                    edge_count+=1
                    for f in e.link_faces:
                        face_indexes.append(f.index)
            if len(face_indexes) > len(list(set(face_indexes))):
                #mark the general corners.
                corner_vert_id += 1
                v[corner_vert_prop] = corner_vert_id

        #inset to create the grooves.
        bm.faces.ensure_lookup_table()
        result = bmesh.ops.inset_region(bm, faces=faces_to_inset, thickness=self.plate_taper, depth=0, use_even_offset=True, use_outset=True)


        #the inset operation will have created the sides of the plates. Mark them as so.
        for f in result['faces']:
            f[groove_face_prop] = 0
            f[groove_inner_face_prop] = 0
            f[plate_side_face_prop] = 1

        #we can now determine which edges are around the outside of the plates.
        bm.faces.ensure_lookup_table()
        plate_tops = []

        groove_faces = []
        plate_verts = []
        for f in bm.faces:
            #mark the faces if they are not grooves or side plates, depending on whether
            #there was a selection in the first place. if there was, it depends if it was marked.
            #if there wasn't, just mark the plate as selected.
            if ((not is_face_selection_present) or f[face_selected_prop]) and \
                (not (f[groove_face_prop] or f[plate_side_face_prop])):
                f[plate_face_prop] = 1
                f[plate_inner_face_prop] = 1
                plate_tops.append(f)
            elif f[groove_face_prop]:
                groove_faces.append(f)

        #__shrink_fatten the faces using a custom function (inset operation produces bad geometry).
        __shrink_fatten(bm, groove_faces, -self.groove_depth)

        #if the min and max height values are other than zero, randomly adjust the heights of the plates
        if (self.plate_min_height != 0 or self.plate_max_height != 0):
            rng_plate_heights = np.random.RandomState(self.plate_height_random_seed)
            #traverse around each plate face and assemble them into groups
            plates = []
            for f in plate_tops:
                face_group = []
                __find_face_group(f, face_group, plate_face_prop, plate_face_group_prop)
                if len(face_group) > 0:
                    plate = {}
                    # vary the heights of each group
                    height = rng_plate_heights.uniform(self.plate_min_height, self.plate_max_height)
                    __shrink_fatten(bm, face_group, height)



        #perform a bevel on the outer plates and/or grooves if necessary
        # find the grooves and select one more.
        plate_edges_to_bevel = []
        groove_edges_to_bevel = []
        if self.bevel_amount > 0.000 or self.groove_bevel_amount > 0.000:
            bm.faces.ensure_lookup_table()
            faces_to_extend = []
            for f in bm.faces:
                if f[groove_face_prop] == 1:
                    faces_to_extend.append(f)

            result = bmesh.ops.region_extend(bm, geom=faces_to_extend, use_faces=True)['geom']
            faces_to_extend.extend(result)

            #identify the edges to bevel.
            for f in result:
                for loop in f.loops:
                    adjacent_f = loop.link_loop_radial_next.face
                    if not (adjacent_f[groove_face_prop] or adjacent_f[plate_side_face_prop]):
                        plate_edges_to_bevel.append(loop.edge)
                        plate_edges_to_bevel.append(loop.edge.verts[0])
                        plate_edges_to_bevel.append(loop.edge.verts[1])



            #bevel the outside of the plates.
            bevelled_plate_edges = bmesh.ops.bevel(bm,
                                            geom=list(set(plate_edges_to_bevel)),
                                            offset=self.bevel_amount,
                                            segments=self.bevel_segments,
                                            offset_type=int(self.bevel_outer_bevel_type),
                                            vertex_only=False,
                                            clamp_overlap=False,
                                            profile=0.5,
                                            loop_slide=True,
                                            material=-1)

            #mark the resulted bevel as plates, not sides.
            for f in bevelled_plate_edges['faces']:
                f[plate_face_prop] = 1
                f[plate_inner_face_prop] = 0
                f[plate_side_face_prop] = 0

            for f in bm.faces:
                if f[groove_face_prop] == 1:
                    for loop in f.loops:
                        adjacent_f = loop.link_loop_radial_next.face
                        if adjacent_f[plate_side_face_prop] == 1:
                            groove_edges_to_bevel.append(loop.edge)
                            groove_edges_to_bevel.append(loop.edge.verts[0])
                            groove_edges_to_bevel.append(loop.edge.verts[1])

            #bevel the outside of the plates.
            bevelled_plate_edges = bmesh.ops.bevel(bm,
                                            geom=list(set(groove_edges_to_bevel)),
                                            offset=self.groove_bevel_amount,
                                            segments=self.groove_bevel_segments,
                                            offset_type=int(self.groove_bevel_outer_bevel_type),
                                            vertex_only=False,
                                            clamp_overlap=False,
                                            profile=0.5,
                                            loop_slide=True,
                                            material=-1)

            #mark the resulted bevel as grooves, not sides.
            for f in bevelled_plate_edges['faces']:
                f[groove_face_prop] = 1
                f[groove_inner_face_prop] = 0
                f[plate_side_face_prop] = 0

        #segment the sides and/or grooves of the plates if necessary.
        if self.side_segments > 1 or self.groove_segments > 1:
            bm.faces.ensure_lookup_table()
            side_edges_to_subdivide = []
            groove_edges_to_subdivide = []
            #find the edges that need to be sibdivided.
            for f in bm.faces:
                if f[plate_side_face_prop]:
                    for loop in f.loops:
                        if loop.link_loop_radial_next.face[plate_side_face_prop]:
                            side_edges_to_subdivide.append(loop.edge)
                if f[groove_inner_face_prop]:
                    for loop in f.loops:
                        if loop.link_loop_radial_next.face[groove_inner_face_prop]:
                            groove_edges_to_subdivide.append(loop.edge)
            #subdivide sides.
            bmesh.ops.subdivide_edges(bm, edges=list(set(side_edges_to_subdivide)), cuts=self.side_segments-1, use_grid_fill=True, use_only_quads=False, smooth=0.0)
            #subbdivide grooves.
            result = bmesh.ops.subdivide_edges(bm, edges=list(set(groove_edges_to_subdivide)), cuts=self.groove_segments-1, use_grid_fill=True, use_only_quads=False, smooth=0.0)
            for v in result['geom']:
                if isinstance(v, bmesh.types.BMVert):
                    v[corner_vert_prop] = 0

        #apply a greeble function if needed...
        if greeble_func != None:
            greeble_faces = []
            for f in bm.faces:
                if self.greeble_plates and f[plate_inner_face_prop]:
                    greeble_faces.append(f)
                if self.greeble_sides and f[plate_side_face_prop]:
                    greeble_faces.append(f)
                if self.greeble_grooves and f[groove_inner_face_prop]:
                    greeble_faces.append(f)
            greeble_func(self, context, bm, greeble_faces, self.greeble_amount)

        #bevel the main corners of the plates if necessary.
        if self.corner_width > 0 or self.minor_corner_width > 0:
            #find all the corners and bevel them if needed
            #find the grooves and select one more.
            bm.edges.ensure_lookup_table()

            major_corners_to_bevel = {}
            minor_corners_to_bevel = {}

            #find the main corners that are not connected to one another and share a uniquie id.
            for e in bm.edges:
                if self.corner_width > 0 and \
                    ((e.verts[0][main_corner_vert_prop] and e.verts[1][main_corner_vert_prop]) and \
                    (e.verts[0][main_corner_vert_prop] == e.verts[1][main_corner_vert_prop])):
                    prop_id = e.verts[0][main_corner_vert_prop]
                    #group the corners to bevel by the id of the main corner.
                    if not prop_id in major_corners_to_bevel:
                        major_corners_to_bevel[prop_id] = []
                    major_corners_to_bevel[prop_id].append(e)
                    major_corners_to_bevel[prop_id].append(e.verts[0])
                    major_corners_to_bevel[prop_id].append(e.verts[1])
                if self.minor_corner_width > 0 and \
                    ((not (e.verts[0][main_corner_vert_prop] and e.verts[1][main_corner_vert_prop])) and \
                    (e.verts[0][corner_vert_prop] and e.verts[1][corner_vert_prop]) and \
                    (e.verts[0][corner_vert_prop] == e.verts[1][corner_vert_prop])):
                    prop_id = e.verts[0][corner_vert_prop]
                    if not prop_id in minor_corners_to_bevel:
                        minor_corners_to_bevel[prop_id] = []
                    minor_corners_to_bevel[prop_id].append(e)
                    minor_corners_to_bevel[prop_id].append(e.verts[0])
                    minor_corners_to_bevel[prop_id].append(e.verts[1])


            #if there are any major corners to bevel, do this.
            for key, corner_edges in major_corners_to_bevel.items():
                if len(corner_edges) > 0:
                    result = bevelled_corner_edges = bmesh.ops.bevel(bm,
                                                    geom=list(set(corner_edges)),
                                                    offset=self.corner_width,
                                                    segments=self.corner_bevel_segments,
                                                    offset_type=int(self.corner_outer_bevel_type),
                                                    vertex_only=False,
                                                    clamp_overlap=False,
                                                    profile=0.5,
                                                    loop_slide=True,
                                                    material=-1)

                    for f in result['faces']:
                        adjacent_groove_count = 0
                        for loop in f.loops:
                            if not (loop.link_loop_radial_next.face[groove_face_prop] or \
                                loop.link_loop_radial_next.face[plate_side_face_prop]):
                                adjacent_groove_count += 1
                        if adjacent_groove_count == 3:
                            f[groove_face_prop] = 0
                            f[groove_inner_face_prop] = 0
                            f[plate_side_face_prop] = 0

            #if there are any minor corners to bevel, do this.
            for key, corner_edges in minor_corners_to_bevel.items():
                if len(corner_edges) > 0:
                    result = bevelled_corner_edges = bmesh.ops.bevel(bm,
                                                    geom=list(set(corner_edges)),
                                                    offset=self.minor_corner_width,
                                                    segments=self.minor_corner_bevel_segments,
                                                    offset_type=int(self.minor_corner_outer_bevel_type),
                                                    vertex_only=False,
                                                    clamp_overlap=False,
                                                    profile=0.5,
                                                    loop_slide=True,
                                                    material=-1)
                    for f in result['faces']:
                        adjacent_groove_count = 0
                        for loop in f.loops:
                            if loop.link_loop_radial_next.face[groove_inner_face_prop]:
                                adjacent_groove_count += 1
                        if adjacent_groove_count == 3:
                            f[groove_face_prop] = 1
                            f[groove_inner_face_prop] = 1

        #delete grooves if required.
        if self.remove_grooves:
            bm.faces.ensure_lookup_table()
            #inner_grooves = [f for f in bm.faces if f[groove_inner_face_prop]]
            #result = inner_grooves + bmesh.ops.region_extend(bm, geom=inner_grooves, use_faces=True)['geom']
            result = [f for f in bm.faces if f[groove_face_prop] or f[plate_side_face_prop]]
            bmesh.ops.delete(bm, geom=result, context=5)

        #perform split operations if required.
        if (self.edge_split or self.mark_seams):
            # find the grooves and select one more.
            bm.faces.ensure_lookup_table()
            edges_to_mark = []
            faces_to_extend = []
            for f in bm.faces:
                if f[groove_inner_face_prop] == 1:
                    for loop in f.loops:
                        if loop.link_loop_radial_next.face[groove_inner_face_prop] == 0:
                            loop.edge.seam=self.mark_seams
                            edges_to_mark.append(loop.edge)
                if f[groove_face_prop] == 1:
                    faces_to_extend.append(f)
                    for loop in f.loops:
                        if loop.link_loop_radial_next.face[groove_face_prop] == 0:
                            loop.edge.seam=self.mark_seams
                            edges_to_mark.append(loop.edge)

            for i in range(self.side_segments):
                result = bmesh.ops.region_extend(bm, geom=faces_to_extend, use_faces=True)['geom']
                for f in result:
                    f[groove_and_side_face_prop] = 1
                faces_to_extend.extend(result)

            #mark seams
            for f in result:
                for loop in f.loops:
                    if loop.link_loop_radial_next.face[groove_and_side_face_prop] == 0:
                        loop.edge.seam=self.mark_seams

            #split edges
            if self.edge_split:

                #split around the edges if necessary.
                for f in result:
                    for loop in f.loops:
                        if loop.link_loop_radial_next.face[groove_and_side_face_prop] == 0:
                            edges_to_mark.append(loop.edge)

                #if we have also bevelled the plates, extend to this region as well.
                if self.bevel_amount > 0:
                    for i in range(self.bevel_segments):
                        result = bmesh.ops.region_extend(bm, geom=faces_to_extend, use_faces=True)['geom']
                        for f in result:
                            f[groove_and_side_face_prop] = 1
                        faces_to_extend.extend(result)

                    for f in result:
                        for loop in f.loops:
                            if loop.link_loop_radial_next.face[groove_and_side_face_prop] == 0:
                                edges_to_mark.append(loop.edge)

                #if necessary also add any corners to split.
                bm.edges.ensure_lookup_table()
                for e in bm.edges:
                    if ((self.corner_width > 0) and \
                        (e.verts[0][main_corner_vert_prop] and e.verts[1][main_corner_vert_prop])) or \
                        ((self.minor_corner_width > 0) and \
                        (e.verts[0][corner_vert_prop] and e.verts[1][corner_vert_prop])):
                            #ignore corners as they are bevelled
                        continue
                    if self.minor_corner_width == 0 and \
                        (e.verts[0][corner_vert_prop] and e.verts[1][corner_vert_prop]) and \
                        (e.verts[0][corner_vert_prop] == e.verts[1][corner_vert_prop]):
                        edges_to_mark.append(e)

                bmesh.ops.split_edges(bm, edges = list(set(edges_to_mark)))

        if self.use_rivets:
            #add in rivets...
            bm.verts.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            rivet_coords = {}
            for v in bm.verts:
                if v[corner_vert_prop] or v[main_corner_vert_prop]:
                    for f in v.link_faces:
                        if f[plate_inner_face_prop]:
                            av_edge_vec = Vector((0,0,0))
                            av_edge_count = 0
                            for e in f.edges:
                                if e.verts[0].index == v.index:
                                    av_edge_count += 1
                                    av_edge_vec += (e.verts[1].co - e.verts[0].co).normalized()
                                if e.verts[1].index == v.index:
                                    av_edge_count += 1
                                    av_edge_vec += (e.verts[0].co - e.verts[1].co).normalized()
                            av_edge_vec = (av_edge_vec / av_edge_count).normalized()
                            rivet_coord = v.co + (av_edge_vec * self.rivet_corner_distance)
                            mat_loc = mathutils.Matrix.Translation(rivet_coord)

                            corner_id = 0
                            #we are assuming the ids are unique
                            if v[corner_vert_prop]:
                                corner_id = v[corner_vert_prop]
                            if v[main_corner_vert_prop]:
                                corner_id = v[main_corner_vert_prop]

                            corner_id = str(f.index) + '-' + str(corner_id)

                            if not corner_id in rivet_coords:
                                rivet_coords[corner_id] = []

                            rivet_coords[corner_id].append(rivet_coord)

            #now we know all this, create the rivets
            for key, corner_coords in rivet_coords.items():
                rivet_coord = functools.reduce(lambda x, y: x + y, corner_coords) / len(corner_coords)
                mat_loc = mathutils.Matrix.Translation(rivet_coord)
                result = bmesh.ops.create_icosphere(bm, subdivisions=self.rivet_subdivisions, diameter=self.rivet_diameter, matrix=mat_loc, calc_uvs = False)
                if self.rivet_material_index > -1:
                    for v in result['verts']:
                        for f in v.link_faces:
                            f.material_index = self.rivet_material_index


        # if self.select_grooves or self.select_plates:
        #ensure all grooves are selected.
        bm.faces.ensure_lookup_table()
        for f in bm.faces:
            f.select = (self.select_grooves and f[groove_face_prop]) or (self.select_plates and f[plate_face_prop])

def __shrink_fatten(bm, faces, amount):
    """Custom function to perform shrink and fatten operations"""
    verts = {}
    for f in faces:
        for v in f.verts:
            if v in verts:
                verts[v].append(f)
            else:
                verts[v] = [f]

    for v in verts:
        unique_faces = verts[v]
        normals = [f.normal for f in unique_faces]
        if len(normals) > 0:
            av_normal = normals[0]
            for normal in normals[1:]:
                av_normal = av_normal + normal
            av_normal = av_normal / len(normals)
            v.co += amount * av_normal.normalized()

    bm.normal_update()

def __find_face_group(f, face_group, plate_face_prop, plate_face_group_prop):
    """Used to find a group of faces for the plates."""
    #just return if this face has already been marked.
    if f[plate_face_group_prop] == 1 or f[plate_face_prop] == 0:
        return
    #otherwise, add this to the following list.
    f[plate_face_group_prop] = 1
    faces_to_find = [f]

    while (len(faces_to_find) > 0):
        next_faces_to_find = []
        for new_face in faces_to_find:
            face_group.append(new_face)

            for v in new_face.verts:
                for link_face in v.link_faces:
                    if link_face[plate_face_group_prop] == 0 and link_face[plate_face_prop] == 1:
                        link_face[plate_face_group_prop] = 1
                        next_faces_to_find.append(link_face)

        faces_to_find = next_faces_to_find

def __mark_groove_edges(bm, e, groove_edge_marked_prop):
    """Go through and mark the edges around a groove."""
    edges_to_return = []

    if e[groove_edge_marked_prop] | e.is_boundary:
        return edges_to_return


    e[groove_edge_marked_prop] = 1
    edges_to_return.append(e)
    edges_to_return.append(e.verts[0])
    edges_to_return.append(e.verts[1])

    # get BMLoop that points to the right direction
    for loop in e.link_loops:
        if len(loop.vert.link_edges) == 4:
            next_loop = loop
            while len(next_loop.vert.link_edges) == 4:

                #are we about to cross a groove boundary? If so, break out of the loop.
                groove_count = 0
                for edge_to_check in next_loop.vert.link_edges:
                    if edge_to_check[groove_edge_marked_prop]:
                        groove_count+=1
                if groove_count > 1:
                    break

                #this is a direction we can go in
                next_loop = next_loop.link_loop_prev.link_loop_radial_prev.link_loop_prev

                edge_to_mark = next_loop.edge

                if edge_to_mark[groove_edge_marked_prop] | edge_to_mark.is_boundary:
                    break
                else:
                    edge_to_mark[groove_edge_marked_prop] = 1
                    edges_to_return.append(edge_to_mark)
                    edges_to_return.append(edge_to_mark.verts[0])
                    edges_to_return.append(edge_to_mark.verts[1])

    return edges_to_return
