import bpy
import bmesh
from . import plating_ui
from . import plating_functions
from bpy.props import (
        IntProperty,
        BoolProperty,
        FloatProperty,
        StringProperty,
        CollectionProperty
        )

#
# Class that contains plate creation logic.
#
class PlateGenerator:
    """Generate Plating Pattern"""


    pattern_type = bpy.props.EnumProperty(items= (('0', 'Generated', ''),
                                                     ('1', 'Selected Edges', '')),
                                                     name = "Pattern Type", default='0')

    random_seed = IntProperty(
        name="Random Seed",
        description="Seed for generating plating pattern",
        default=123456,
        )

    amount = IntProperty(
        name="Amount",
        description="Number of times a plate cut will be made",
        min=1,
        default=50,
        )

    groove_width = FloatProperty(
            name="Groove Width",
            description="Bevel width of grooves",
            min=0.001,
            default=0.01,
            precision=3,
            step=1
            )

    clamp_grooves = BoolProperty(
            name="Clamp Groove Width",
            description="Attempt to prevent grooves from overlapping",
            default=False,
            )

    groove_depth = FloatProperty(
        name="Groove Depth",
        description="Depth of grooves",
        default=0.01,
        precision=3,
        step=1
        )

    groove_segments = IntProperty (
            name="Groove Segments",
            description="Number of segments inside the grooves",
            min=1,
            max=10,
            default=1,
    )

    side_segments = IntProperty (
            name="Plate Side Segments",
            description="Number of segments on the side of the plates",
            min=1,
            max=10,
            default=1,
    )

    bevel_amount = FloatProperty(
            name="Plate Bevel Amount",
            description="How bevelled are the top of the plates",
            min=0.000,
            default=0.000,
            precision=3,
            step=1
            )

    bevel_segments = IntProperty(
            name="Plate Bevel Segments",
            description="How many segments the plate bevel has",
            min=1,
            default=1,
            )

    bevel_outer_bevel_type = bpy.props.EnumProperty(items= (('0', 'Offset', ''),
                                                     ('1', 'Width', ''),
                                                     ('2', 'Depth', ''),
                                                     ('3', 'Percent', '')),
                                                     name = "Plate Bevel Type", default='0')

    groove_bevel_amount = FloatProperty(
            name="Groove Bevel Amount",
            description="How bevelled are the grooves between the plates",
            min=0.000,
            default=0.000,
            precision=3,
            step=1
            )

    groove_bevel_segments = IntProperty(
            name="Groove Bevel Segments",
            description="How many segments the groove bevel has",
            min=1,
            default=1,
            )

    groove_bevel_outer_bevel_type = bpy.props.EnumProperty(items= (('0', 'Offset', ''),
                                                     ('1', 'Width', ''),
                                                     ('2', 'Depth', ''),
                                                     ('3', 'Percent', '')),
                                                     name = "Groove Bevel Type", default='0')

    plate_min_height = FloatProperty(
            name="Min Plate Height",
            description="Minimum Plate Height",
            default=0.000,
            precision=3,
            step=1
            )

    plate_max_height = FloatProperty(
            name="Max Plate Height",
            description="Maximum Plate Height",
            default=0.000,
            precision=3,
            step=1
            )

    plate_height_random_seed = IntProperty(
        name="Plate Height Random Seed",
        description="Seed for generating plating heights",
        default=123456,
        )

    plate_taper = FloatProperty(
            name="Plate Taper",
            description="Plate taper amount",
            default=0.000,
            precision=3,
            step=1
            )

    select_grooves = BoolProperty(
            name="Select Grooves",
            description="Select groove topology",
            default=False,
            )

    select_plates = BoolProperty(
            name="Select Plates",
            description="Select plate topology",
            default=True,
            )

    mark_seams = BoolProperty(
            name="Mark UV Seams",
            description="Mark UV Seams for texture mapping",
            default=False,
            )

    edge_split = BoolProperty(
            name="Edge Split",
            description="Apply an edge split to clearly display the grooves",
            default=False,
            )

    remove_grooves = BoolProperty(
            name="Remove Grooves",
            description="Remove the grooves to just leave the plates",
            default=False,
            )

    edge_selection_only = BoolProperty(
            name="Edge Selection Only",
            description="Only output the edge selection on the mesh",
            default=False,
            )

    corner_width = FloatProperty(
            name="Main Corner Width",
            description="Bevel width of corners",
            min=0.000,
            default=0.0,
            precision=3,
            step=1
            )

    corner_bevel_segments = IntProperty(
            name="Main Corner Bevel Segments",
            description="How bevelled are the corners of the selection",
            min=1,
            default=1,
            )

    corner_outer_bevel_type = bpy.props.EnumProperty(items= (('0', 'Offset', ''),
                                                     ('1', 'Width', ''),
                                                     ('2', 'Depth', ''),
                                                     ('3', 'Percent', '')),
                                                     name = "Major Corner Bevel Type", default='0')

    minor_corner_width = FloatProperty(
            name="Minor Corner Width",
            description="Bevel width of corners",
            min=0.000,
            default=0.0,
            precision=3,
            step=1
            )

    minor_corner_bevel_segments = IntProperty(
            name="Minor Corner Bevel Segments",
            description="How bevelled are the corners of the selection",
            min=1,
            default=1,
            )

    minor_corner_outer_bevel_type = bpy.props.EnumProperty(items= (('0', 'Offset', ''),
                                                     ('1', 'Width', ''),
                                                     ('2', 'Depth', ''),
                                                     ('3', 'Percent', '')),
                                                     name = "Minor Corner Bevel Type", default='0')

    use_rivets = BoolProperty(
            name="Use Rivets",
            description="Whether to add rivet shapes to the plates",
            default=False
            )

    rivet_corner_distance = FloatProperty(
            name="Distance from Corner",
            description="distance of rivets from corners",
            min=0.000,
            default=0.05,
            precision=3,
            step=1
            )

    rivet_diameter = FloatProperty(
            name="Diameter",
            description="Diameter of rivets",
            min=0.000,
            default=0.01,
            precision=3,
            step=1
            )

    rivet_subdivisions = IntProperty(
            name="Subdivisions",
            description="rivet sphere subdivisions",
            min=1,
            max=8,
            default=1
            )

    rivet_material_index  = IntProperty(
            name="Material Index",
            description="rivet material index slot",
            default=-1
            )

    #cosmetics
    update_draw_only= BoolProperty(default=False, options={'SKIP_SAVE'})
    def update_draw(self, context):
        self.update_draw_only = True

    show_plating_pattern_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_grooves_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_plates_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_corners_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_selection_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_rivets_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_other_options_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})

    # draw out a custom interface as there are a lot of properties.
    def draw(self, context):
        print('drawing')
        plating_ui.draw(self, self.layout)

    @classmethod
    def poll(cls, context):
        return context.active_object and \
            ((context.active_object.type == 'MESH' and \
            context.active_object.mode == 'OBJECT') or \
            (context.active_object.type == 'MESH' and \
            context.active_object.mode == 'EDIT' and \
            context.scene.tool_settings.mesh_select_mode[2]) or \
            (context.active_object.type == 'MESH' and \
            context.active_object.mode == 'EDIT' and \
            context.scene.tool_settings.mesh_select_mode[1]))

    def execute(self, context):
        print('executing')
        if self.update_draw_only:
            self.update_draw_only = False
            return {'PASS_THROUGH'}

        if bpy.ops.object.mode_set.poll():
            #capture previous edit mode
            previous_mode = bpy.context.active_object.mode
            previous_edit_mode = list(bpy.context.tool_settings.mesh_select_mode)

            # Switching to EDIT edge mode
            bpy.ops.object.mode_set(mode = 'EDIT')

            # read mesh data
            obj = context.edit_object
            me = obj.data
            bm = bmesh.from_edit_mesh(me)

            #call the plate pattern generator.
            plating_functions.create_plates(self, context, bm)

            # update the bmmesh
            bmesh.update_edit_mesh(obj.data)
            me.calc_tessface()

            #reset to previous mode
            if not self.edge_selection_only:
                context.tool_settings.mesh_select_mode = previous_edit_mode
            else:
                context.tool_settings.mesh_select_mode = (False, True, False)

            bpy.ops.object.mode_set(mode = previous_mode)
            return {'FINISHED'}
        return {'CANCELLED'}

    def check(self, context):
        return True
