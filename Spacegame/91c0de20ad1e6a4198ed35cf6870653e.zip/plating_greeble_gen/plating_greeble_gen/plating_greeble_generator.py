import bpy
from ..plating_gen import plating_generator
from ..plating_gen import plating_ui
from ..plating_gen import plating_functions
from ..greeble_gen import greeble_generator
from ..greeble_gen import greeble_ui
from ..greeble_gen import greeble_functions
import bmesh
from bpy.props import (
        BoolProperty
        )

class PlateGreebleGenerator(plating_generator.PlateGenerator, greeble_generator.GreebleGenerator):
    """Generate Plating Pattern and Greebles"""

    use_plates = BoolProperty(
            name="Generate Plates",
            description="Create the plates",
            default=True,
            )

    use_greebles = BoolProperty(
            name="Generate Greebles",
            description="Create the greebles",
            default=True,
            )

    greeble_plates = BoolProperty(
            name="Greeble Plates",
            description="Greeble Plates",
            default=True,
            )

    greeble_sides = BoolProperty(
            name="Greeble Sides",
            description="Greeble Sides",
            default=False,
            )

    greeble_grooves = BoolProperty(
            name="Greeble Grooves",
            description="Greeble Grooves",
            default=False,
            )

    apply_updates = BoolProperty(
            name="Apply Updates",
            description="Apply the updates",
            default=True,
            )


    #cosmetics
    update_draw_only= BoolProperty(default=False, options={'SKIP_SAVE'})
    def update_draw(self, context):
        self.update_draw_only = True

    show_plates_opt_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_greebles_opt_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})
    show_updates_opt_panel = BoolProperty(default=False,update=update_draw, options={'SKIP_SAVE'})


    # draw out a custom interface as there are a lot of properties.
    def draw(self, context):
        layout = self.layout
        col = layout.column()

        box = col.box()
        row = box.row()
        row.prop(self, "show_plates_opt_panel",
            icon="TRIA_DOWN" if self.show_plates_opt_panel else "TRIA_RIGHT",
            icon_only=True, emboss=False
        )
        row.label(text="Plates")
        if self.show_plates_opt_panel:
            box.prop(self, "use_plates")
            plating_col = box.column()
            plating_col.enabled = self.use_plates
            # plating_col.separator()
            plating_ui.draw(self, plating_col)

        box = col.box()
        row = box.row()
        row.prop(self, "show_greebles_opt_panel",
            icon="TRIA_DOWN" if self.show_greebles_opt_panel else "TRIA_RIGHT",
            icon_only=True, emboss=False
        )
        row.label(text="Greebles")
        if self.show_greebles_opt_panel:
            box.prop(self, "use_greebles")
            greeble_col = box.column()
            greeble_col.enabled = self.use_greebles
            # greeble_col.separator()
            row = greeble_col.row()
            row.label(text="Apply to: ")
            row = greeble_col.row()
            row.prop(self, "greeble_plates", text="Plates")
            row.prop(self, "greeble_sides", text="Sides")
            row.prop(self, "greeble_grooves", text="Grooves")
            greeble_col.separator()

            greeble_ui.draw(self, greeble_col)

        box = col.box()
        row = box.row()
        row.prop(self, "show_updates_opt_panel",
            icon="TRIA_DOWN" if self.show_updates_opt_panel else "TRIA_RIGHT",
            icon_only=True, emboss=False
        )
        row.label(text="Apply Updates")
        if self.show_updates_opt_panel:
            updates_opt_panel = box.column()
            updates_opt_panel.prop(self, "apply_updates")

    def execute(self, context):
        if not self.apply_updates:
            return {'PASS_THROUGH'}
        if self.update_draw_only:
            self.update_draw_only = False
            return {'PASS_THROUGH'}
        if bpy.ops.object.mode_set.poll():
            #capture previous edit mode
            previous_mode = bpy.context.active_object.mode
            previous_edit_mode = list(bpy.context.tool_settings.mesh_select_mode)

            # Switching to EDIT edge mode
            bpy.ops.object.mode_set(mode = 'EDIT')

            # read mesh data
            obj = context.edit_object
            me = obj.data
            bm = bmesh.from_edit_mesh(me)

            #call the plate pattern generator.
            if self.use_plates:
                greeble_func = None
                if self.use_greebles:
                    greeble_func = greeble_functions.add_greebles
                plating_functions.create_plates(self, context, bm, greeble_func)
            elif self.use_greebles:
                greeble_faces = []
                for f in bm.faces:
                    if f.select:
                        greeble_faces.append(f)
                greeble_functions.add_greebles(self, context, bm, greeble_faces, self.greeble_amount)

            # update the bmmesh
            bmesh.update_edit_mesh(obj.data)
            me.calc_tessface()

            #reset to previous mode
            if not self.edge_selection_only:
                context.tool_settings.mesh_select_mode = previous_edit_mode
            else:
                context.tool_settings.mesh_select_mode = (False, True, False)

            bpy.ops.object.mode_set(mode = previous_mode)

            return {'FINISHED'}
        return {'CANCELLED'}

    def check(self, context):
        return True

class PlateGreebleGeneratorOperator(bpy.types.Operator, PlateGreebleGenerator):
    bl_idname = "mesh.plates_greebles_generate"
    bl_label = "Generate Plates"
    bl_options = {'REGISTER', 'UNDO', 'PRESET'}

def __plate_greeble_menu_func(self, context):
    self.layout.operator(PlateGreebleGeneratorOperator.bl_idname)

def append_to_menu():
    # lets add ourselves to the main header
    bpy.types.VIEW3D_MT_object.append(__plate_greeble_menu_func)
    bpy.types.VIEW3D_MT_edit_mesh.append(__plate_greeble_menu_func)

def remove_from_menu():
    bpy.types.VIEW3D_MT_edit_mesh.remove(__plate_greeble_menu_func)
    bpy.types.VIEW3D_MT_object.remove(__plate_greeble_menu_func)
