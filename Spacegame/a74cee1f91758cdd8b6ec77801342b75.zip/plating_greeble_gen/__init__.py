bl_info = {
    "name": "Generate Plates with Greebles",
    "author": "Mark Kingsnorth",
    "version": (1, 10, 0),
    "blender": (2, 80, 0),
    "description": "Plating and Greebles Generator",
    "warning": "",
    "wiki_url": "",
    "category": "Mesh",
    }
# To support reload properly, try to access a package var,
# if it's there, reload everything
if "bpy" in locals():
    import imp
    imp.reload(plating_functions)
    imp.reload(plating_generator)
    imp.reload(plating_ui)
    imp.reload(standard_greeble_objects)
    imp.reload(greeble_functions)
    imp.reload(greeble_generator)
    imp.reload(greeble_ui)
    imp.reload(plating_greeble_generator)
    print("Reloaded greeble files")
else:
    from .plating_gen import plating_functions
    from .plating_gen import plating_generator
    from .plating_gen import plating_ui
    from .greeble_gen import standard_greeble_objects
    from .greeble_gen import greeble_functions
    from .greeble_gen import greeble_generator
    from .greeble_gen import greeble_ui
    from .plating_greeble_gen import plating_greeble_generator
    print("Imported greeble and plating files")

import bpy

classes = [greeble_generator.SceneGreebleObject, plating_greeble_generator.MESH_OT_PlateGreebleGeneratorOperator]

# register, unregister = bpy.utils.register_classes_factory(classes)
def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    plating_greeble_generator.append_to_menu()

def unregister():
    plating_greeble_generator.remove_from_menu()
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)


if __name__ == "__main__":
    register()
